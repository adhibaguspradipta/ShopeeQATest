import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil
import org.openqa.selenium.Keys as Keys

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When


class GistStep {
	/**
	 * The step definitions below match with Katalon sample Gherkin steps
	 */
	@Given("I want login to GitHub with username (.*) and password (.*)")
	def loginGit(String username, String password){
		WebUI.openBrowser('https://github.com/login')
		WebUI.maximizeWindow()
		WebUI.sendKeys(findTestObject('Gist/LoginPage-Username'), username)
		WebUI.sendKeys(findTestObject('Gist/LoginPage-Password'), password)
		WebUI.click(findTestObject('Gist/LoginPage-SubmitBtn'))
	}
	
	@Then("I want to logout from GitHub")
	def logoutGit(){
		WebUI.click(findTestObject('Gist/gistMenuIcon'))
		WebUI.click(findTestObject('Gist/gistSignOut'))
		WebUI.click(findTestObject('Gist/gistConfirmSignOut'))
		WebUI.delay(3)
		WebUI.closeBrowser()
	}
	
	@Given("I want to create a public gist")
	def createPublicGist() {
		WebUI.click(findTestObject('Gist/gistMenuIcon'))
		WebUI.click(findTestObject('Gist/gistMenuYourGist'))
		WebUI.waitForElementPresent(findTestObject('Gist/gistadhi'), 30)
		WebUI.click(findTestObject('Gist/createGist'))
		WebUI.sendKeys(findTestObject('Gist/gistDesc'), 'Gist1')
		WebUI.sendKeys(findTestObject('Gist/gistCode'), 'Shopee QA Test')
//		WebUI.waitForElementPresent('Gist/gistClickContent', 20)
		WebUI.delay(5)
		WebUI.click(findTestObject('Gist/gistClickContent'))
//		WebUI.sendKeys(findTestObject('Gist/gistCodeContent'),Keys.chord(Keys.CONTROL,'A'))
		WebUI.sendKeys(null, 'Test')
		WebUI.click(findTestObject('Gist/gistDropdownBtn'))
		WebUI.click(findTestObject('Gist/gistPublicOpt'))	
		WebUI.click(findTestObject('Gist/gistSubmitPublicBtn'))
	}
	
	@Given("I want to edit existing gist")
	def editGist() {
		WebUI.click(findTestObject('Gist/gistMenuIcon'))
		WebUI.click(findTestObject('Gist/gistMenuYourGist'))
		WebUI.waitForElementPresent(findTestObject('Gist/gistadhi'), 30)
		WebUI.click(findTestObject('Gist/gistDetailUrl'))
		WebUI.click(findTestObject('Gist/gistEditBtn'))
		WebUI.click(findTestObject('Gist/gistClickContent'))
		WebUI.sendKeys(null, 'Test ABCD')
		WebUI.click(findTestObject('Gist/gistUpdateBtn'))
	}
	
	@Given("I want to see list of my gist")
	def seeGist() {
		WebUI.click(findTestObject('Gist/gistMenuIcon'))
		WebUI.click(findTestObject('Gist/gistMenuYourGist'))
		WebUI.waitForElementPresent(findTestObject('Gist/gistadhi'), 30)
	}
	
	@Given("List of gist displayed")
	def listGist() {
		WebUI.waitForElementPresent(findTestObject('Gist/gistadhi'), 30)
		WebUI.delay(10)
	}
	
	@Given("I want to delete existing gist")
	def deleteGist() {
		WebUI.click(findTestObject('Gist/gistMenuIcon'))
		WebUI.click(findTestObject('Gist/gistMenuYourGist'))
		WebUI.waitForElementPresent(findTestObject('Gist/gistadhi'), 30)
		WebUI.click(findTestObject('Gist/gistDetailUrl'))
		WebUI.click(findTestObject('Gist/gistDeleteBtn'))
		WebUI.acceptAlert()
	}

	@When("I check for the (\\d+) in step")
	def I_check_for_the_value_in_step(int value) {
		println value
	}

	@Then("Gist deleted successfully")
	def gistDeleted() {
		WebUI.waitForElementPresent(findTestObject('Gist/gistDeletedSuccessfully'), 30)
	}
	
	@Then("Gist created")
	def gistCreated(){
		WebUI.waitForElementPresent(findTestObject('Gist/gistCreatedSuccessfully'), 30)
	}
	
	@Then("Gist edited")
	def gistEdited(){
		WebUI.waitForElementPresent(findTestObject('Gist/gistCreatedSuccessfully'), 30)
	}
}